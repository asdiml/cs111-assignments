#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <termios.h>
#include <unistd.h>
#include <linux/limits.h>
#include "tokenizer.h"

/* Convenience macro to silence compiler warnings about unused function
 * parameters. */
#define unused __attribute__((unused))

/* Whether the shell is connected to an actual terminal or not. */
bool shell_is_interactive;

/* File descriptor for the shell input */
int shell_terminal;

/* Terminal mode settings for the shell */
struct termios shell_tmodes;

/* Process group id for the shell */
pid_t shell_pgid;

int cmd_exit(struct tokens *tokens);
int cmd_help(struct tokens *tokens);
int cmd_cd(struct tokens *tokens);
int cmd_pwd();

/* Built-in command functions take token array (see parse.h) and return int */
typedef int cmd_fun_t(struct tokens *tokens);

/* Built-in command struct and lookup table */
typedef struct fun_desc {
    cmd_fun_t *fun;
    char *cmd;
    char *doc;
} fun_desc_t;

fun_desc_t cmd_table[] = {
    {cmd_help, "?", "show this help menu"},
    {cmd_exit, "exit", "exit the command shell"},
    {cmd_cd, "cd", "change directory"},
    {cmd_pwd, "pwd", "print working directory"},
};
int cmd_cd(unused struct tokens *tokens) {
    if (tokens_get_length(tokens) == 1) {
        fprintf(stderr, "cd: missing argument\n");
        return -1;
    }
    if (tokens_get_length(tokens) > 2) {
        fprintf(stderr, "cd: too many arguments\n");
        return -1;
    }
    char *path = tokens_get_token(tokens, 1);
    if (chdir(path) == 0) {
        return 0;
    } else {
        perror("cd");
        return -1;
    }
}
int cmd_pwd() {
    char cwd[PATH_MAX];
    if (getcwd(cwd, sizeof(cwd)) != NULL) {
        printf("%s\n", cwd);
        return 0;
    } else {
        perror("getcwd() error");
        return 1;
    }
}
/* Prints a helpful description for the given command */
int cmd_help(unused struct tokens *tokens) {
    for (unsigned int i = 0; i < sizeof(cmd_table) / sizeof(fun_desc_t); i++) {
        printf("%s - %s\n", cmd_table[i].cmd, cmd_table[i].doc);
    }
    return 1;
}

/* Exits this shell */
int cmd_exit(unused struct tokens *tokens) {
    exit(0);
}

/* Looks up the built-in command, if it exists. */
int lookup(char *cmd) {
    if (cmd != NULL) {
        for (int i = 0; i < sizeof(cmd_table) / sizeof(fun_desc_t); i++) {
            if (strcmp(cmd_table[i].cmd, cmd) == 0) {
                return i;
            }
        }
    }
    return -1;
}

/* Intialization procedures for this shell */
void init_shell() {
    /* Our shell is connected to standard input. */
    shell_terminal = STDIN_FILENO;

    /* Check if we are running interactively */
    shell_is_interactive = isatty(shell_terminal);

    if (shell_is_interactive) {
        /* If the shell is not currently in the foreground, we must pause the
         * shell until it becomes a foreground process. We use SIGTTIN to pause
         * the shell. When the shell gets moved to the foreground, we'll receive
         * a SIGCONT. */
        while (tcgetpgrp(shell_terminal) != (shell_pgid = getpgrp())) {
            kill(-shell_pgid, SIGTTIN);
        }

        /* Saves the shell's process id */
        shell_pgid = getpid();

        /* Take control of the terminal */
        tcsetpgrp(shell_terminal, shell_pgid);

        /* Save the current termios to a variable, so it can be restored later.
         */
        tcgetattr(shell_terminal, &shell_tmodes);
    }
}


char** process_arguments(struct tokens *tokens, char **infile, char **outfile) {
    int token_count = tokens_get_length(tokens);
    char **args = malloc((token_count + 1) * sizeof(char *));
    
    if (!args) {
        perror("malloc");
        return NULL;
    }
    
    args[0] = tokens_get_token(tokens, 0); // Program name
    
    int j = 1;
    for (int i = 1; i < token_count; i++) {
        char *tok = tokens_get_token(tokens, i);
        
        if (strcmp(tok, ">") == 0 && (i + 1) < token_count) {
            *outfile = tokens_get_token(tokens, ++i);
        }
        else if (strcmp(tok, "<") == 0 && (i + 1) < token_count) {
            *infile = tokens_get_token(tokens, ++i);
        } else {
            args[j++] = tok;
        }
    }
    args[j] = NULL; // Null-terminate the argument array for execv
    
    return args;
}

int main(unused int argc, unused char *argv[]) {

    init_shell();
    signal(SIGINT, SIG_IGN);
    signal(SIGTTOU, SIG_IGN);
    signal(SIGTSTP, SIG_IGN);

    static char line[4096];
    int line_num = 0;

    /* Only print shell prompts when standard input is not a tty */
    if (shell_is_interactive) {
        fprintf(stdout, "%d: ", line_num);
    }

    while (fgets(line, 4096, stdin)) {
        /* Split our line into words. */
        struct tokens *tokens = tokenize(line);

        /* Find which built-in function to run. */
        int fundex = lookup(tokens_get_token(tokens, 0));

        if (fundex >= 0) {
            cmd_table[fundex].fun(tokens);
        } else {
            /* REPLACE this to run commands as programs. */
            char *original_path = getenv("PATH");
            char *path_copy = strdup(original_path); 
            if (path_copy == NULL) {
                perror("strdup");
                continue;
            }
            char *token = strtok(path_copy, ":");
            char *program = tokens_get_token(tokens, 0);
            
            char *infile = NULL;
            char *outfile = NULL;
            char **args = process_arguments(tokens, &infile, &outfile);
            if (!args) {
                fprintf(stderr, "Failed to process command arguments\n");
                continue;
            }

            // I/O redirection handling
            if (infile != NULL) {
                int fd = open(infile, O_RDONLY);
                if (fd == -1) {
                    perror("open");
                    free(args);
                    continue;
                }
                if (dup2(fd, STDIN_FILENO) == -1) {
                    perror("dup2");
                    close(fd);
                    free(args);
                    continue;
                }
                close(fd);
            }
            
            if (outfile != NULL) {
                int fd = open(outfile, O_WRONLY | O_CREAT | O_TRUNC, 0644);
                if (fd == -1) {
                    perror("open");
                    free(args);
                    continue;
                }
                if (dup2(fd, STDOUT_FILENO) == -1) {
                    perror("dup2");
                    close(fd);
                    free(args);
                    continue;
                }
                close(fd);
            }

            pid_t pid = fork();
            if (pid < 0) {
                perror("fork");
                free(args);
            } 
            else if (pid == 0) {
                setpgid(0, 0);
                tcsetpgrp(shell_terminal, getpid());
                signal(SIGINT, SIG_DFL);
                signal(SIGTTOU, SIG_DFL);
                signal(SIGTSTP, SIG_DFL);

                if (program[0] == '/' || program[0] == '.') {
                    args[0] = program;
                    execv(program, args);
                }

                char abs_path[1024];
                while (token != NULL) {
                    strcpy(abs_path, token);
                    strcat(abs_path, "/");
                    strcat(abs_path, program);
                    args[0] = abs_path;
                    execv(abs_path, args);
                    token = strtok(NULL, ":");
                }
                
                fprintf(stderr, "%s: command not found\n", program);
                free(args);
                exit(1);    
            } else if (pid > 0) {
                wait(NULL);
                free(path_copy);
            }
            
        }

        if (shell_is_interactive) {
            /* Only print shell prompts when standard input is not a tty. */
            fprintf(stdout, "%d: ", ++line_num);
        }

        /* Clean up memory. */
        tokens_destroy(tokens);

        tcsetpgrp(0, getpid());
        signal(SIGINT, SIG_IGN);
        signal(SIGTTOU, SIG_IGN);
        signal(SIGTSTP, SIG_IGN);
    }

    return 0;
}
